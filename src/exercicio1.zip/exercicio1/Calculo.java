package exercicio1;

import java.util.List;

public interface Calculo {

    double calculo(List<Double> list);
}
